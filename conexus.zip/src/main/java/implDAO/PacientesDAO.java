package implDAO;

import conexusDTO.PacientesDTO;
import iDAO.IPacientesDAO;

public class PacientesDAO implements IPacientesDAO {

	@Override
	public boolean save(PacientesDTO pacientesObjDTO) {
		//PacientesDTO pacientes= new PacientesDTO();
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(PacientesDTO pacientesObjDTO) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean findByIdUser(PacientesDTO pacientesObjDTO) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean delete(PacientesDTO pacientesObjDTO) {
		// TODO Auto-generated method stub
		return false;
	}



}
